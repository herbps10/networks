gcc -g -I/home/herb/igraph-0.5.4/src/ -ligraph -lpthread -o networks src/networks.c -std=c99
